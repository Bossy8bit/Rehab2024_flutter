import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Thai (`th`).
class AppLocalizationsTh extends AppLocalizations {
  AppLocalizationsTh([String locale = 'th']) : super(locale);

  @override
  String get menu => 'เมนู';

  @override
  String get details => 'รายละเอียด';

  @override
  String get gotohome => 'ไปที่หน้าโฮม';

  @override
  String get mainpage => 'หน้าหลัก';

  @override
  String get myProfile => 'โปรไฟล์ของฉัน';

  @override
  String get myPatients => 'ผู้ป่วยของฉัน';

  @override
  String get favoriteExercise => 'สร้างใบสั่งใหม่';

  @override
  String get exerciseList => 'รายการท่า';

  @override
  String get qrCode => 'คิวอาร์โค้ด';

  @override
  String get byAnatomy => 'ตามโครงสร้าง';

  @override
  String get bySymtoms => 'ตามอาการ';

  @override
  String get byFavorite => 'ตามรายกสรชื่นชอบ';

  @override
  String get addExercise => 'เพิ่มท่ารายการ';

  @override
  String get neck => 'คอ';

  @override
  String get shoulder => 'หัวไหล่';

  @override
  String get arm => 'แขน';

  @override
  String get back => 'หลัง';

  @override
  String get waist => 'สะโพก';

  @override
  String get knee => 'เข่า';

  @override
  String get ankle => 'ข้อเท้า';

  @override
  String get feet => 'เท้า';

  @override
  String get cameraPermission => 'กรุณาอนุญาติสิทธ์เพื่อการเข้าถึงกล้อง';

  @override
  String get scanQrcode => 'สแกน QR Code';

  @override
  String get scannedData => 'สแกน ข้อมูล';

  @override
  String get noExerciseAvailable => 'ไม่มีท่าที่ใช้ได้';

  @override
  String get searchwithHNorName => 'ค้นหาด้วย HN หรือ ชื่อ-นามสกุล';
}
