import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get menu => 'Menu';

  @override
  String get details => 'details';

  @override
  String get gotohome => 'gotohome';

  @override
  String get mainpage => 'Main Page';

  @override
  String get myProfile => 'My Profile';

  @override
  String get myPatients => 'My Patients';

  @override
  String get favoriteExercise => 'Favorite Exercise';

  @override
  String get exerciseList => 'Exercise List';

  @override
  String get qrCode => 'QR Code';

  @override
  String get byAnatomy => 'ByAnatomy';

  @override
  String get bySymtoms => 'BySymtoms';

  @override
  String get byFavorite => 'ByFavorite';

  @override
  String get addExercise => 'AddExercise';

  @override
  String get neck => 'Neck';

  @override
  String get shoulder => 'Shoulder';

  @override
  String get arm => 'Arm';

  @override
  String get back => 'Back';

  @override
  String get waist => 'Waist';

  @override
  String get knee => 'Knee';

  @override
  String get ankle => 'Ankle';

  @override
  String get feet => 'Feet';

  @override
  String get cameraPermission => 'Camera permission is required to scan QR codes.';

  @override
  String get scanQrcode => 'Scan a QR Code';

  @override
  String get scannedData => 'Scanned Data';

  @override
  String get noExerciseAvailable => 'No exercise available';

  @override
  String get searchwithHNorName => 'Search with HN or name-surname';
}
