package com.example.rehab2024

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
