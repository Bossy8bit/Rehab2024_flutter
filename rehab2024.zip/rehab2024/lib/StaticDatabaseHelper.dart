import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class StaticDatabaseHelper {
  static final StaticDatabaseHelper instance = StaticDatabaseHelper._internal();
  StaticDatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'rehab2024.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await _createTable(db);
        await _populateTable(db);
      },
    );
  }
  Future<List<Map<String, dynamic>>> fetchFavoriteExercises() async {
  try {
    final db = await database; // Ensure the database is properly initialized
    return await db.query(
      'exercises',
      where: 'isFavorite = ?', // Query only favorite exercises
      whereArgs: [1],
    );
  } catch (e) {
    print('❌ Error fetching favorite exercises: $e');
    return []; // Return an empty list if an error occurs
  }
}

  /// Define the schema
  Future<void> _createTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS exercises (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT CHECK (type IN ('S', 'F')) NOT NULL, 
        side TEXT CHECK (side IN ('Left', 'Right', 'All')) NOT NULL, 
        anatomy TEXT CHECK (anatomy IN ('neck', 'shoulder', 'arm', 'back', 'hip', 'knee', 'ankle', 'foot')) DEFAULT NULL, 
        symptom TEXT CHECK (symptom IN ('OA_knee', 'frozen_shoulder', 'Low_back_pain')) DEFAULT NULL, 
        holdFor INTEGER DEFAULT 0 NOT NULL,
        repeatFor INTEGER DEFAULT 0 NOT NULL,
        doPerDay INTEGER DEFAULT 0 NOT NULL,
        isChecked INTEGER DEFAULT 0 NOT NULL,
        isFavorite INTEGER DEFAULT 0 NOT NULL,
        image TEXT,
        description TEXT DEFAULT ''
      )
    ''');
    print("✅ Table created.");
  }
  

  /// Populate the table with static data
  Future<void> _populateTable(Database db) async {
   await db.insert('exercises', {
  'name': 'Stretching left splenius muscle',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'neck',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left upper trapezius muscle ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left upper trapezius muscle ท่า 2',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left levator scapulae muscle',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left pectoralis major muscle',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left quadratus lumborum muscle ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'back',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left quadratus lumborum muscle ท่า 2',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'back',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left quadratus lumborum muscle ท่า 3',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'back',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left gluteus maximus muscle ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left gluteus maximus muscle ท่า 2',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left gluteus maximus muscle ท่า 3',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left hip flexor muscle',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left quadriceps muscle ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left hamstring muscle',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left gastrocnemius muscle ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'ankle',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left gastrocnemius ท่า 2',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'ankle',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Isometric neck exercise',
  'type': 'S',
  'side': 'nan',
  'anatomy': 'neck',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left shoulder muscles (Wall Push-up)',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 0,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening external rotator muscle of left shoulder ท่า 1',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left shoulder external rotator muscle ท่า 2',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening internal rotator muscle of left shoulder',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left shoulder flexor muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left supraspinatus muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Pelvic tilt',
  'type': 'S',
  'side': 'nan',
  'anatomy': 'back',
  'symptom': 'Low_back_pain',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Semi sit-up (strengthening abdominal muscle)',
  'type': 'S',
  'side': 'nan',
  'anatomy': 'back',
  'symptom': 'Low_back_pain',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Knee prank (strengthening trunk muscle)',
  'type': 'S',
  'side': 'nan',
  'anatomy': 'back',
  'symptom': 'Low_back_pain',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening gluteus maximus muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left gluteus maximus muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left quadriceps muscle (open kinetic chain)',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'OA_knee',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left VMO muscle (open kinetic chain)',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'OA_knee',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left quadriceps muscle (closed kinetic chain)',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'OA_knee',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left hamstring muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'OA_knee',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching posterior capsule of left shoulder',
  'type': 'F',
  'side': 'Left',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left shoulder into flexion',
  'type': 'F',
  'side': 'Left',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left shoulder into internal rotation ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left shoulder into internal rotation ท่า 2',
  'type': 'F',
  'side': 'Left',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left shoulder into external rotation ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left shoulder into external rotation ท่า 2',
  'type': 'F',
  'side': 'Left',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left shoulder into horizontal abduction',
  'type': 'F',
  'side': 'Left',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right splenius muscle',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'neck',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right upper trapezius muscle ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right upper trapezius muscle ท่า 2',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right levator scapulae muscle',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right pectoralis major muscle',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right quadratus lumborum muscle ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'back',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right quadratus lumborum muscle ท่า 2',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'back',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right quadratus lumborum muscle ท่า 3',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'back',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left lower back ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'back',
  'symptom': 'Low_back_pain',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right lower back ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'back',
  'symptom': 'Low_back_pain',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching lower back muscle ท่า 2',
  'type': 'F',
  'side': 'nan',
  'anatomy': 'back',
  'symptom': 'NULL',
  'holdFor': 0,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Knee to chest',
  'type': 'F',
  'side': 'nan',
  'anatomy': 'back',
  'symptom': 'Low_back_pain',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right gluteus maximus muscle ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right gluteus maximus muscle ท่า 2',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right gluteus maximus muscle ท่า 3',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right hip flexor muscle',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right quadriceps muscle ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right hamstring muscle',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right gastrocnemius muscle ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'ankle',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right gastrocnemius ท่า 2',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'ankle',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right shoulder muscles (Wall Push-up)',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 0,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening external rotator muscle of right shoulder ท่า 1',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right shoulder external rotator muscle ท่า 2',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right supraspinatus muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening gluteus maximus muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right gluteus maximus muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right quadriceps muscle (open kinetic chain)',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'OA_knee',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right VMO muscle (open kinetic chain)',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'OA_knee',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right quadriceps muscle (closed kinetic chain)',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'OA_knee',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right hamstring muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'OA_knee',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching posterior capsule of right shoulder',
  'type': 'F',
  'side': 'Right',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right shoulder into flexion',
  'type': 'F',
  'side': 'Right',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right shoulder into internal rotation ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right shoulder into internal rotation ท่า 2',
  'type': 'F',
  'side': 'Right',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right shoulder into external rotation ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right shoulder into external rotation ท่า 2',
  'type': 'F',
  'side': 'Right',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right shoulder into horizontal abduction',
  'type': 'F',
  'side': 'Right',
  'anatomy': '-',
  'symptom': 'frozen_shoulder',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left sternocleidomastoid muscle',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'neck',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left triceps brachii muscle',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'arm',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching upper back',
  'type': 'F',
  'side': 'nan',
  'anatomy': 'back',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left hip adductor muscle ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left hip adductor muscle ท่า 2',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left ITB band ท่า 1',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left ITB band ท่า 2',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching left plantar fascia',
  'type': 'F',
  'side': 'Left',
  'anatomy': 'foot',
  'symptom': 'NULL',
  'holdFor': 0,
  'repeatFor': 0,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Seated Push-up',
  'type': 'S',
  'side': 'nan',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left middle trapezius muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left lower trapezius muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left triceps brachii muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'arm',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Foot prank (strengthening trunk muscle)',
  'type': 'S',
  'side': 'nan',
  'anatomy': 'back',
  'symptom': 'Low_back_pain',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left hip external rotator muscle',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left gluteus medius muscle ท่า 1',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening left gluteus medius muscle ท่า 2',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'isometric left quadriceps exercise',
  'type': 'S',
  'side': 'Left',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening tibialis posterior muscle',
  'type': 'S',
  'side': 'nan',
  'anatomy': 'ankle',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening intrinsic foot muscle',
  'type': 'S',
  'side': 'nan',
  'anatomy': 'foot',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right sternocleidomastoid muscle',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'neck',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right triceps brachii muscle',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'arm',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right hip adductor muscle ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right hip adductor muscle ท่า 2',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right ITB band ท่า 1',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right ITB band ท่า 2',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Stretching right plantar fascia',
  'type': 'F',
  'side': 'Right',
  'anatomy': 'foot',
  'symptom': 'NULL',
  'holdFor': 0,
  'repeatFor': 0,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right middle trapezius muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right lower trapezius muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right triceps brachii muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'arm',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right hip external rotator muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right gluteus medius muscle ท่า 1',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right gluteus medius muscle ท่า 2',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'hip',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'isometric right quadriceps exercise',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'knee',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening internal rotator muscle of right shoulder',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

await db.insert('exercises', {
  'name': 'Strengthening right shoulder flexor muscle',
  'type': 'S',
  'side': 'Right',
  'anatomy': 'shoulder',
  'symptom': 'NULL',
  'holdFor': 10,
  'repeatFor': 10,
  'doPerDay': 3,
  'isChecked': 0,
  'isFavorite': 0,
  'image': '',
  'description': ''
});

    
    print("✅ Table populated with static data.");
  }
}
