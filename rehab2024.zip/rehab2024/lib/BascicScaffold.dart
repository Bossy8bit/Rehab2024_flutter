import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'CustomScaffold.dart';

class BasicScaffold extends StatelessWidget {
  final Function(Locale) changeLanguage;

  BasicScaffold({required this.changeLanguage});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      changeLanguage: changeLanguage,
      appBar: AppBar(
        title: Text('Exercise List'),
        backgroundColor: Colors.blue,
      ),
      body: Column()
    );
  }
}
