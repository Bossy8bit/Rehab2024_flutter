## first 
### build apk --debug 
### and see in androind folder